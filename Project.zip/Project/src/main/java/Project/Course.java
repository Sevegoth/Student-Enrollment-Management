package itcs.labs.finalProject;


import java.util.ArrayList;
import java.util.Scanner;

public class Course {
    /**
     * a variable that store courses In one year that students have to learn
     */
    private ArrayList<String> coursesInYear;
    /**
     * a variable to store courses that registered
     */
    private final ArrayList<String> registeredCourse = new ArrayList<>();

    /**
     * a constructor for course object
     * @param a ArrayList
     */
    Course(ArrayList<String> a){
        coursesInYear = a;
    }

    /**
     * a constructor without param for using the method directly without any more operation
     */
    public Course() {
    }

    /**
     * converting String type to ArrayList<String> type
     * @param grade 1st or 2nd or 3rd or 4th
     * @return an ArrayList that have converted
     */
    public ArrayList<String> toList(int grade){
        if(grade == 1){
            ArrayList<String> coursesInYear1 = new ArrayList<>();
            Scanner s = new Scanner(coursesInYear.get(0));
            while(s.hasNext()){
                coursesInYear1.add(s.next());
            }
            return coursesInYear1;
        } else if (grade==2) {
            ArrayList<String> coursesInYear2 = new ArrayList<>();
            Scanner s = new Scanner(coursesInYear.get(1));
            while(s.hasNext()){
                coursesInYear2.add(s.next());
            }
            return coursesInYear2;
        } else if (grade == 3) {
            ArrayList<String> coursesInYear3 = new ArrayList<>();
            Scanner s = new Scanner(coursesInYear.get(2));
            while(s.hasNext()){
                coursesInYear3.add(s.next());
            }
            return coursesInYear3;
        } else if (grade == 4) {
            ArrayList<String> coursesInYear4 = new ArrayList<>();
            Scanner s = new Scanner(coursesInYear.get(3));
            while(s.hasNext()){
                coursesInYear4.add(s.next());
            }
            return coursesInYear4;
        }
        return coursesInYear;
    }

    /**
     * a method to add courses for register operation
     * @param course a string of course ID
     */
    public void setRegisteredCourse(String course){
        registeredCourse.add(course);
    }

    /**
     * a method to get the courses that registered
     * @return an ArrayList<String> of course ,which is registered,id
     */
    public ArrayList<String> getRegisteredCourse() {
        return registeredCourse;
    }
}
