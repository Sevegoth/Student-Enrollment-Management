package itcs.labs.finalProject;

import java.util.ArrayList;

public class Student implements Register{
    /**
     * variable to store grade level
     */
    private int grade =0;
    /**
     * variable to store courses object
     */
    private final ArrayList<Course> c = new ArrayList<>();


    /**
     * a constructor of student
     * @param studentId String type of one student's id
     * @param coursesInYear courses in one year which student have to study
     * @param courseWanted courses student want to register
     * @param coursePassed courses student have passed
     */
    public Student(String studentId,ArrayList<String> coursesInYear,ArrayList<String> courseWanted,ArrayList<String> coursePassed) {
        c.add(new Course(coursesInYear));
        c.add(new WillingCourse(courseWanted));
        c.add(new PassedCourse(coursePassed));
        switch (studentId.substring(0, 2)) {
            case "61" -> grade = 4;
            case "62" -> grade = 3;
            case "63" -> grade = 2;
            case "64" -> grade = 1;
        }

    }


    /**
     * method to get different types of course(passed or want to register)
     * @param type of course that want to return
     * @return an arrayList of that kind of course
     */
    public ArrayList<String> getCourse(String type){
        if(type.equals("willing")){
            return c.get(1).toList(grade);
        } else if (type.equals("passed")) {
            return c.get(2).toList(grade);
        }
        return c.get(0).toList(grade);
    }


    /**
     * a method to register courses
     * @param course the course that want to register
     */
    @Override
    public void registerCourses(String course) {
        if(grade == 1){
            c.get(0).setRegisteredCourse(course);
        }
    }

    /**
     * get the grade level of that student(1,2,3,4)
     * @return int of grade
     */
    public int getGrade() {
        return grade;
    }

    /**
     * get the arrayList of courses object
     * @return an arrayList of course object
     */
    public ArrayList<Course> getC() {
        return c;
    }

}
