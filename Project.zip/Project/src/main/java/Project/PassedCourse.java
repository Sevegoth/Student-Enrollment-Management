package itcs.labs.finalProject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class PassedCourse extends Course implements HardRequirement{
    /**
     * a variable to store courses in a year which student have to learn
     */
    private final ArrayList<String> courseInYear = new ArrayList<>();
    /**
     * a variable to store student id
     */
    private String id;

    /**
     * a constructor of this object
     * @param a an array list of passed courses
     */
    public PassedCourse(ArrayList<String> a) {
        super(a);
    }

    /**
     * a constructor without param for using method directly
     */
    public PassedCourse(){
    }

    /**
     * a constructor to get student id to write to file
     * @param b string of ids
     */
    public PassedCourse(String b){
        id = b;
    }

    /**
     * a method to write output to target file
     * @param outputFile file that use to store outcomes
     * @throws IOException Exception detecting
     */
    @Override
    public void writeToFile(File outputFile) throws IOException {// true -> append
        FileOutputStream fs = new FileOutputStream(outputFile, true);
        PrintWriter out = new PrintWriter(fs);
        out.printf("%s%s","StudentId: ",id);
        out.println("\n");
        out.close();
    }

    /**
     * a method to read something from file
     * @param inputFile target file
     * @throws IOException Exception detecting
     * @throws NoSuchElementException Exception detecting
     */
    @Override
    public void readFromFile(File inputFile) throws IOException, NoSuchElementException {
        Scanner fileIn2 = new Scanner(inputFile);// course
        while(fileIn2.hasNext()){
            Scanner id = new Scanner(fileIn2.nextLine());
            while(id.hasNext()){
                id.next();
                id.next();
                courseInYear.add(id.nextLine());
            }
        }
    }

    /**
     * a method to get courses in one year which student have to learn
     * @return array list of course id
     */
    public ArrayList<String> getCourseInYear() {
        return courseInYear;
    }
}
