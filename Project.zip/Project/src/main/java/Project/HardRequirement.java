package itcs.labs.finalProject;
import java.io.File;
import java.io.IOException;
import java.util.NoSuchElementException;

public interface HardRequirement {
    /**
     * a method to write something to target file
     * @param outputFile  file that use to store outcomes
     * @throws IOException Exception detecting
     */
    void writeToFile(File outputFile)
            throws IOException;

    /**
     * a method to read something from target file
     * @param inputFile target file
     * @throws IOException Exception detecting
     * @throws NoSuchElementException Exception detecting
     */
    void readFromFile(File inputFile)
            throws IOException, NoSuchElementException;
}
