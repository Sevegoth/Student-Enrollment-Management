package itcs.labs.finalProject;

import java.util.ArrayList;

public class Year3 extends Student{
    /**
     * a variable that store the condition that the course have meet
     */
    private int count = 0;

    /**
     * a constructor of this kind of object
     * @param studentId String
     * @param coursesInYear ArrayList<String>
     * @param courseWanted ArrayList<String>
     * @param coursePassed ArrayList<String>
     */
    public Year3(String studentId, ArrayList<String> coursesInYear, ArrayList<String> courseWanted, ArrayList<String> coursePassed) {
        super(studentId, coursesInYear, courseWanted, coursePassed);
    }

    /**
     * a method to register courses for 3rd year
     * @param course the course that want to register
     */
    @Override
    public void registerCourses(String course) {
        for (String a : super.getC().get(0).toList(super.getGrade())) {
            if (course.equals("a")) {
                count++;
            }
            if (a.equals("19") || a.equals("20")) {
                for (String b : super.getC().get(2).toList(super.getGrade())) {
                    if (b.equals("12")) {
                        count++;
                    }
                }
            }
        }
        if (count <= 2) {
            super.getC().get(0).setRegisteredCourse(course);
        }
    }
}
