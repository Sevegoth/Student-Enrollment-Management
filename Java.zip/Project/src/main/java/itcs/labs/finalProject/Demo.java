package itcs.labs.finalProject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class Demo {
    /**
     * a static method main to run code
     * @param args standard param
     * @throws IOException Exception detecting
     */
    public static void main(String[] args) throws IOException {

        File f = new File("src/main/java/itcs/labs/finalProject/Students");// id
        File f2 = new File("src/main/java/itcs/labs/finalProject/Classes");// courses
        File f3 = new File("src/main/java/itcs/labs/finalProject/coursesWantRegister");// courses

        FileOperation h = new FileOperation();
        h.readFromFile(f);
        WillingCourse h2 = new WillingCourse();
        h2.readFromFile(f3);
        PassedCourse h3 = new PassedCourse();
        h3.readFromFile(f2);


        //get students courses in one year
        ArrayList<Student> s = new ArrayList<>();
        s.add(new Student(h.getIds().get(0), h3.getCourseInYear(), h2.getCourseWantRegister(), h.getCoursePassed()));
        s.add(new Year2(h.getIds().get(1), h3.getCourseInYear(), h2.getCourseWantRegister(), h.getCoursePassed()));
        s.add(new Year3(h.getIds().get(2), h3.getCourseInYear(), h2.getCourseWantRegister(), h.getCoursePassed()));
        s.add(new Year4(h.getIds().get(3), h3.getCourseInYear(), h2.getCourseWantRegister(), h.getCoursePassed()));


        //register
        for (String a : s.get(0).getCourse("willing")) {
            s.get(0).registerCourses(a);
        }
        for (String a : s.get(1).getCourse("willing")) {
            s.get(1).registerCourses(a);
        }
        for (String a : s.get(2).getCourse("willing")) {
            s.get(2).registerCourses(a);
        }
        for (String a : s.get(3).getCourse("willing")) {
            s.get(3).registerCourses(a);
        }

        //output
        File o = new File("src/main/java/itcs/labs/finalProject/Schedule");
        WillingCourse w = new WillingCourse();
        PassedCourse p = new PassedCourse();
        for (int i = 0; i < 4; i++) {
            if (i == 0) {
                for (int j = 0; j < s.get(i).getC().get(0).getRegisteredCourse().size(); j++) {
                    w = new WillingCourse(i + 1, s.get(i).getC().get(0).getRegisteredCourse());
                    p = new PassedCourse(h.getIds().get(0));
                }
            } else if (i == 1) {
                for (int j = 0; j < s.get(i).getC().get(0).getRegisteredCourse().size(); j++) {
                    w = new WillingCourse(i + 1, s.get(i).getC().get(0).getRegisteredCourse());
                    p = new PassedCourse(h.getIds().get(1));
                }
            } else if (i == 2) {
                for (int j = 0; j < s.get(i).getC().get(0).getRegisteredCourse().size(); j++) {
                    w = new WillingCourse(i + 1, s.get(i).getC().get(0).getRegisteredCourse());
                    p = new PassedCourse(h.getIds().get(2));
                }
            } else {
                for (int j = 0; j < s.get(i).getC().get(0).getRegisteredCourse().size(); j++) {
                    w = new WillingCourse(i + 1, s.get(i).getC().get(0).getRegisteredCourse());
                    p = new PassedCourse(h.getIds().get(3));
                }
            }
            h.writeToFile(o);
            w.writeToFile(o);
            p.writeToFile(o);
        }
    }



}
