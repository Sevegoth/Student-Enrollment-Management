package itcs.labs.finalProject;

import java.util.ArrayList;

public class Year4 extends Student{
    /**
     * a variable that store the condition that the course have meet
     */
    private int count = 0;

    /**
     * a constructor for this kind of object
     * @param studentId String
     * @param coursesInYear ArrayList<String>
     * @param courseWanted ArrayList<String>
     * @param coursePassed ArrayList<String>
     */
    public Year4(String studentId, ArrayList<String> coursesInYear, ArrayList<String> courseWanted, ArrayList<String> coursePassed) {
        super(studentId, coursesInYear, courseWanted, coursePassed);
    }

    /**
     * a method to register course for fourth year
     * @param course the course that want to register
     */
    @Override
    public void registerCourses(String course) {
        for (String b : super.getC().get(2).toList(super.getGrade())) {
            if (b.equals("5")||b.equals("12")||b.equals("20")) {
                count++;
            }
        }
        if (count <= 3) {
            super.getC().get(0).setRegisteredCourse(course);
        }
    }
}
