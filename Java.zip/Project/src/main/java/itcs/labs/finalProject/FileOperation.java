package itcs.labs.finalProject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class FileOperation implements HardRequirement{
    /**
     * a variable to store students' id
     */
    private final ArrayList<String> ids = new ArrayList<>();
    /**
     * a variable to store courses that have passed
     */
    private final ArrayList<String> coursePassed = new ArrayList<>();

    /**
     * a method to write into a file as output
     * @param outputFile file that use to store outcomes
     * @throws IOException Exception detecting
     */
    @Override
    public void writeToFile(File outputFile) throws IOException {
        FileOutputStream fs = new FileOutputStream(outputFile, true);
        PrintWriter out = new PrintWriter(fs);
        out.printf("Classes info\n");
        out.close();
    }

    /**
     * @param inputFile target file
     * @throws IOException Exception detecting
     * @throws NoSuchElementException Exception detecting
     */
    @Override
    public void readFromFile(File inputFile) throws IOException, NoSuchElementException {
        Scanner fileIn = new Scanner(inputFile);
        while(fileIn.hasNext()){
            Scanner id = new Scanner(fileIn.nextLine());
            ids.add(id.next());// students id
            while(id.hasNext()){
                Scanner courseId = new Scanner(id.nextLine());
                while(courseId.hasNext()) {
                    coursePassed.add(courseId.next());// courses passed
                }
            }
        }
    }

    /**
     * a method to get id
     * @return array list of students' id
     */
    public ArrayList<String> getIds() {
        return ids;
    }

    /**
     * a method to get courses which student have passed
     * @return array list of courses' id
     */
    public ArrayList<String> getCoursePassed() {
        return coursePassed;
    }
}
