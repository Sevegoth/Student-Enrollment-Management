package itcs.labs.finalProject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class WillingCourse extends Course implements HardRequirement{
    /**
     * a variable to store course that student Want to Register
     */
    private final ArrayList<String> courseWantRegister = new ArrayList<>();
    /**
     * a variable to store course that student Registered
     */
    private final ArrayList<String> courseHaveRegister = new ArrayList<>();

    /**
     * a constructor for Willing course with one param
     * @param a ArrayList<String>
     */
    public WillingCourse(ArrayList<String> a) {
        super(a);
    }

    /**
     * a constructor for Willing course without param for using method without operation
     */
    public WillingCourse(){}

    /**
     * a constructor for Willing course which is receiving course that have registered
     * @param ignoredGrade int for differing from WillingCourse(ArrayList<String> a)
     * @param b ArrayList of course that have registered
     */
    public WillingCourse(int ignoredGrade, ArrayList<String> b){
        courseHaveRegister.addAll(b);
    }

    /**
     * a method to write into a file as output
     * @param outputFile the file to store outcomes
     * @throws IOException Exception detecting
     */
    @Override
    public void writeToFile(File outputFile) throws IOException {
        FileOutputStream fs = new FileOutputStream(outputFile, true);
        PrintWriter out = new PrintWriter(fs);
        out.printf("%s\n", "Courses have registered:");
        for(String s:courseHaveRegister){
            out.printf("%s\n",s);
        }
        out.close();
    }

    /**
     * a method to read information from a file as input
     * @param inputFile  file that want to read
     * @throws IOException Exception detecting
     * @throws NoSuchElementException Exception detecting
     */
    @Override
    public void readFromFile(File inputFile) throws IOException, NoSuchElementException {
        Scanner fileIn3 = new Scanner(inputFile);//course want to register
        while(fileIn3.hasNext()){
            Scanner id = new Scanner(fileIn3.nextLine());
            while(id.hasNext()){
                id.next();
                courseWantRegister.add(id.nextLine());
            }
        }
    }

    /**
     * a method to get courses that student want to register
     * @return an Arraylist of course id
     */
    public ArrayList<String> getCourseWantRegister() {
        return courseWantRegister;
    }

}
