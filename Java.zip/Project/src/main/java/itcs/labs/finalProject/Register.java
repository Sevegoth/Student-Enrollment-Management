package itcs.labs.finalProject;

public interface Register {
    /**
     * a method to register course
     * @param course id of course
     */
    void registerCourses(String course);
}
